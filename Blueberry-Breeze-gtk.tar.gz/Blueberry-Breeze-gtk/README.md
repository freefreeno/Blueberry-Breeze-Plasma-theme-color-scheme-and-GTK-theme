Blueberry Breeze is the the gtk version of my Blueberry Breeze Plasma theme and color-scheme for use in KDE Plasma for more uniform look and feel.
